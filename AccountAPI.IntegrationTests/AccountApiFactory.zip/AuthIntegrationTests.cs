using System.Net;
using System.Net.Http.Json;
using FluentAssertions;
using Xunit;
using System.Net;
using System.Net.Http.Json;

namespace AccountAPI.IntegrationTests
{
    public class AuthIntegrationTests : IClassFixture<AccountApiFactory>
    {
        private readonly HttpClient _client;

        public AuthIntegrationTests(AccountApiFactory factory)
        {
            _client = factory.CreateClient();
        }

        [Fact]
        public async Task Register_Should_Return_OK()
        {
            var request = new
            {
                email = "test@test.com",
                password = "Password123!"
            };

            var response = await _client.PostAsJsonAsync("/api/account/register", request);

            response.StatusCode.Should().Be(HttpStatusCode.OK);
        }
    }
}